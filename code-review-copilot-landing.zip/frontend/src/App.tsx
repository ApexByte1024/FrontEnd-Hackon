import { useRef, useState } from "react";
import { api } from "./api";
import type {
  AnalyzeResponse,
  GenerateTestsResponse,
  ApplyFixResponse,
  ScoreResponse,
} from "./types/api";
import { CodeInput } from "./components/CodeInput";
import { IssueList } from "./components/IssueList";
import { DiffViewer } from "./components/DiffViewer";
import { TestResultPanel } from "./components/TestResultPanel";
import { ScoreDisplay } from "./components/ScoreDisplay";
import "./styles/tokens.css";
import "./App.css";

type Stage = "idle" | "analyzing" | "analyzed" | "testing" | "fixing" | "done";

const FEED_ITEMS = [
  "01 / STATIC ANALYSIS",
  "02 / ISSUE TRIAGE",
  "03 / TEST GENERATION",
  "04 / AI PATCH",
  "05 / VERIFICATION",
];

export default function App() {
  const [stage, setStage] = useState<Stage>("idle");
  const [analysis, setAnalysis] = useState<AnalyzeResponse | null>(null);
  const [selectedIssueIds, setSelectedIssueIds] = useState<string[]>([]);
  const [testResult, setTestResult] = useState<GenerateTestsResponse | null>(null);
  const [fixResult, setFixResult] = useState<ApplyFixResponse | null>(null);
  const [score, setScore] = useState<ScoreResponse | null>(null);
  const workspaceRef = useRef<HTMLElement>(null);

  async function handleAnalyze(code: string, filename: string) {
    setStage("analyzing");
    setAnalysis(null);
    setTestResult(null);
    setFixResult(null);
    setScore(null);
    setSelectedIssueIds([]);

    try {
      const result = await api.analyze({ code, filename });
      setAnalysis(result);
      setStage("analyzed");
    } catch {
      setStage("idle");
    }
  }

  function toggleIssueSelect(id: string) {
    setSelectedIssueIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  }

  async function handleGenerateTests() {
    if (!analysis || selectedIssueIds.length === 0) return;
    setStage("testing");
    try {
      const result = await api.generateTests({
        analysis_id: analysis.analysis_id,
        issue_ids: selectedIssueIds,
      });
      setTestResult(result);
      setStage("analyzed");
    } catch {
      setStage("analyzed");
    }
  }

  async function handleApplyFix() {
    if (!analysis || !testResult) return;
    setStage("fixing");
    try {
      const result = await api.applyFix({
        analysis_id: analysis.analysis_id,
        issue_ids: selectedIssueIds,
        test_id: testResult.test_id,
      });
      setFixResult(result);
      const scoreResult = await api.getScore(analysis.analysis_id);
      setScore(scoreResult);
      setStage("done");
    } catch {
      setStage("analyzed");
    }
  }

  function runDemo() {
    workspaceRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  const completedSteps =
    stage === "done" ? 5 : testResult ? 3 : analysis ? 2 : stage === "analyzing" ? 1 : 0;

  return (
    <div className="app">
      <div className="ticker" aria-label="Pipeline activity">
        <div className="ticker__track">
          {[...FEED_ITEMS, ...FEED_ITEMS].map((item, index) => (
            <span className="ticker__item" key={`${item}-${index}`}>
              <span className="ticker__dot" />
              {item}
            </span>
          ))}
        </div>
      </div>

      <header className="site-header">
        <div className="site-header__brand">
          <span className="brand-mark">CR</span>
          <span>CODE REVIEW COPILOT</span>
        </div>
        <div className="site-header__status">
          <span className="status-dot" /> PIPELINE READY
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero__eyebrow">
            <span>BUILD 01</span>
            <span>RELIABLE CODE / LOUD SIGNAL</span>
          </div>

          <div className="hero__grid">
            <div>
              <h1>
                FIND THE BUG.
                <br />
                <span>PROVE THE FIX.</span>
              </h1>
            </div>

            <div className="hero__pitch">
              <p>
                A code-review pipeline that analyzes Python, turns real issues into
                tests, applies a focused patch, and verifies the result.
              </p>
              <button className="hero__cta" onClick={runDemo}>
                <span>RUN IT</span>
                <span className="hero__cta-arrow">↘</span>
              </button>
              <div className="hero__note">ONE CLICK TO THE WORKSPACE ↓</div>
            </div>
          </div>

          <div className="hero__signal">
            <div className="hero__signal-number">01</div>
            <div>
              <strong>ANALYZE → TEST → FIX → VERIFY</strong>
              <span>No hand-waving. Every patch gets a before/after check.</span>
            </div>
          </div>
        </section>

        <section className="steps" aria-label="Pipeline steps">
          {FEED_ITEMS.map((item, index) => (
            <div className={`step ${index < completedSteps ? "step--active" : ""}`} key={item}>
              <span>{String(index + 1).padStart(2, "0")}</span>
              <strong>{item.split(" / ")[1]}</strong>
            </div>
          ))}
        </section>

        <section className="workspace" ref={workspaceRef}>
          <div className="workspace__intro">
            <div>
              <span className="section-kicker">LIVE WORKSPACE</span>
              <h2>PUT CODE UNDER THE LENS.</h2>
            </div>
            <p>
              Paste a file or upload one. Select the issues worth fixing, then let the
              pipeline prove the change.
            </p>
          </div>

          <div className="workspace__grid">
            <section className="workspace__panel workspace__panel--code">
              <div className="panel-label">
                <span>01 / INPUT</span>
                <span>PYTHON</span>
              </div>
              <CodeInput onAnalyze={handleAnalyze} isAnalyzing={stage === "analyzing"} />
            </section>

            <section className="workspace__panel">
              <div className="app__panel-header">
                <div className="panel-label panel-label--plain">
                  <span>02 / FINDINGS</span>
                  {analysis && <span>{analysis.issues.length} SIGNALS</span>}
                </div>
                {analysis && (
                  <button
                    className="btn btn--primary"
                    disabled={selectedIssueIds.length === 0 || stage === "testing"}
                    onClick={handleGenerateTests}
                  >
                    {stage === "testing" ? "GENERATING…" : "GENERATE TESTS"}
                  </button>
                )}
              </div>

              <IssueList
                issues={analysis?.issues ?? []}
                selectedIds={selectedIssueIds}
                onToggleSelect={toggleIssueSelect}
              />

              {testResult && (
                <div className="app__test-fix">
                  <div className="panel-label panel-label--plain">
                    <span>03 / TEST</span>
                    <span>BEFORE PATCH</span>
                  </div>
                  <TestResultPanel label="Before fix" result={testResult.pre_fix_result} />

                  <button
                    className="btn btn--primary btn--wide"
                    disabled={stage === "fixing"}
                    onClick={handleApplyFix}
                  >
                    {stage === "fixing" ? "APPLYING FIX…" : "APPLY AI FIX"}
                  </button>

                  {fixResult && (
                    <>
                      <div className="panel-label panel-label--plain">
                        <span>04 / PATCH</span>
                        <span>UNIFIED DIFF</span>
                      </div>
                      <DiffViewer diff={fixResult.diff} />
                      <div className="panel-label panel-label--plain">
                        <span>05 / VERIFY</span>
                        <span>AFTER PATCH</span>
                      </div>
                      <TestResultPanel label="After fix" result={fixResult.post_fix_result} />
                    </>
                  )}
                </div>
              )}
            </section>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <span>CODE REVIEW COPILOT</span>
        <span>STATIC SIGNAL → VERIFIED CHANGE</span>
        <ScoreDisplay score={score} />
      </footer>
    </div>
  );
}
