# Code Review Copilot — Frontend

## Setup
```bash
npm install
npm run dev
```

Runs on http://localhost:5173.

## Judge-facing landing experience
The app now opens with a bold, black-canvas landing hero inspired by the visual language requested:
- oversized high-contrast typography
- one loud lime accent
- numbered pipeline reveals
- animated live-feed ticker
- one-click `RUN IT` CTA that scrolls directly to the working code-review workspace
- responsive mobile layout

The original working flow remains intact:
1. Paste or upload Python code
2. Analyze code
3. Select issues
4. Generate tests
5. Apply AI fix
6. Review the diff
7. Verify the post-fix test result and score

The UI is still wired to `mockApi.ts` by default. Switch `USE_REAL_API` in `src/api/index.ts` to `true` when the FastAPI backend is ready.

## Structure
`src/App.tsx` contains the landing hero + workspace orchestration.
`src/App.css` contains the visual system and responsive layout.
`src/styles/tokens.css` contains the design tokens.
